// Shop settings: the only node you edit to adapt this workflow to a new shop.
return [{ json: {
  shop_name: 'Nour Store',            // your shop's name, used in AI answers
  currency: 'DA',
  google_sheet_id: 'PASTE_YOUR_GOOGLE_SHEET_ID',
  owner_telegram_chat_id: 'PASTE_YOUR_TELEGRAM_CHAT_ID',
  whatsapp_phone_number_id: 'PASTE_WHATSAPP_PHONE_NUMBER_ID',
  meta_api_version: 'v21.0',
} }];
